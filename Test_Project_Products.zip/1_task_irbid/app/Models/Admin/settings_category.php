<?php
namespace App\Models\Admin;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Http\Controllers\Cookies;  
//7878454545  
class settings_category extends Model
 {
  public $table ="category";
  protected $fillable = [
  "id", 
  "category_en", 
  "category_ar", 
  "created_by",
  "created_at",
  "updated_at",
  "updated_by",
  ];
  public static function rules(){
    //proccess 1000050
     return [
         "category_en"=>["required","string"],
         "category_ar"=>["required","string"],
            ];
  }
} 
