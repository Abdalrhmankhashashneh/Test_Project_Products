<?php
namespace App\Models\Admin;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Http\Controllers\Cookies;  
//7878454545  
class administrator_tbl_users_type extends Model
 {
  public $table ="tbl_users_type";
  protected $fillable = [
  "id", 
  "name", 
  "created_by",
  "created_at",
  "updated_at",
  "updated_by",
  ];
  public static function rules(){
    //proccess 1000050
     return [
         "name"=>["required","string"],
            ];
  }
} 
