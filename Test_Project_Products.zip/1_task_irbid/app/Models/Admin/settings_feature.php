<?php
namespace App\Models\Admin;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Http\Controllers\Cookies;  
//7878454545  
class settings_feature extends Model
 {
  public $table ="feature";
  protected $fillable = [
  "id", 
  "feature_en", 
  "feature_ar", 
  "created_by",
  "created_at",
  "updated_at",
  "updated_by",
  ];
  public static function rules(){
    //proccess 1000050
     return [
         "feature_en"=>["required","string"],
         "feature_ar"=>["required","string"],
            ];
  }
} 
