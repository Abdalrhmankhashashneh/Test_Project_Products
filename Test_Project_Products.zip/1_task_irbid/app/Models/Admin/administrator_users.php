<?php
namespace App\Models\Admin;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Http\Controllers\Cookies;  
//7878454545  
class administrator_users extends Model
 {
  public $table ="users";
  protected $fillable = [
  "id", 
  "name", 
  "email", 
  "profile_photo_path", 
  "tbl_users_type_id", 
  "tbl_users_type_id", 
  "active_status_id", 
  "password",
  "created_by",
  "created_at",
  "updated_at",
  "updated_by",
  ];
  public static function rules(){
    //proccess 1000050
     return [
         "name"=>["required","string"],
         "email"=>["required","string"],
         "profile_photo_path"=>["nullable","mimes:bmp,jpg,jpeg,gif,png","max:50000"],
         "tbl_users_type_id"=>["exists:tbl_users_type,id","required","int"],
            ];
  }
} 
