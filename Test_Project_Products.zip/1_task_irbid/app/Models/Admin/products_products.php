<?php
namespace App\Models\Admin;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Http\Controllers\Cookies;  
//7878454545  
class products_products extends Model
 {
  public $table ="products";
  protected $fillable = [
  "id", 
  "unit_id", 
  "category_id", 
  "price", 
  "qty", 
  "status_id", 
  "feature_id", 
  "desc", 
  "image", 
  "product_name", 
  "created_by",
  "created_at",
  "updated_at",
  "updated_by",
  ];
  public static function rules(){
    //proccess 1000050
     return [
         "unit_id"=>["exists:unit,id","required","int"],
         "category_id"=>["exists:category,id","required","int"],
         "price"=>["required","numeric"],
         "qty"=>["required","numeric"],
         "status_id"=>["exists:status,id","required","int"],
         "feature_id"=>["exists:feature,id","required","int"],
         "desc"=>["nullable","string"],
         "image"=>["nullable","mimes:tif,tiff,bmp,jpg,jpeg,gif,png","max:50000"],
         "product_name"=>["required","string"],
            ];
  }
} 
