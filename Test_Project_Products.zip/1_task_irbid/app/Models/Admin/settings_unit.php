<?php
namespace App\Models\Admin;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Http\Controllers\Cookies;  
//7878454545  
class settings_unit extends Model
 {
  public $table ="unit";
  protected $fillable = [
  "id", 
  "unit_en", 
  "unit_ar", 
  "created_by",
  "created_at",
  "updated_at",
  "updated_by",
  ];
  public static function rules(){
    //proccess 1000050
     return [
         "unit_en"=>["required","string"],
         "unit_ar"=>["required","string"],
            ];
  }
} 
