<?php

namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;

class Admin 
{
  
    public function handle(Request $request, Closure $next)
    {   /*
        tbl_users_type_id = 1 // admin 
        tbl_users_type_id = 2 // normal user
        Another user Type will not Allow to enter AdminPanel
        */
        if(!Auth()->check() ||  Auth()->user()->tbl_users_type_id >= 2 ){
            abort(403);
        }
        
        return $next($request);
    }
}
