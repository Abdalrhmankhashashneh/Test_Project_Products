<?php 
namespace App\Http\Controllers\AdminController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\SystemController\Delete;
use App\Http\Controllers\SystemController\Permission;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use App\Models\Admin\products_products;
use App\Http\Controllers\AdminController\UserAuthController;
class products extends Controller
{
 /*  
  This controller has been generated Automatically by generatesystems.com  
  */ 
/**************Start Table (products) Functionality **************/
function products_products_delete_record(Request $request){
  //  proccess 10000008
 $id=$request->input("id");
 $table=$request->input("table");
 $id_name = $table . "_id";
 if(Delete::checkRow($id_name,$id)){
 return response()->json(array("response"=>"not_allow"));
 }else{
    if(DB::table($table)->where("id", $id)->delete()){                    
      return response()->json(array("response"=>"deleted"));                
  } 
   return response()->json(array("response"=>"error")); 
  }
}
function products_products(Request $request)
  {
  //  proccess 10000007
  $lang =app()->getLocale();   
  $host = request()->getHttpHost();   
  $hostUrl = "https://".$host."/uploads/documents/";  
  $data = products_products::select(    
                  "products.id   AS  id",
                  "unit.unit_$lang    AS  unit_id_unit_en",
                  "products.unit_id   AS  unit_id",
                  "category.category_$lang    AS  category_id_category_en",
                  "products.category_id   AS  category_id",
                  "products.price   AS  price",
                  "products.qty   AS  qty",
                  "status.status_$lang    AS  status_id_status_en",
                  "products.status_id   AS  status_id",
                  "feature.feature_$lang    AS  feature_id_feature_en",
                  "products.feature_id   AS  feature_id",
                  "products.desc   AS  desc",
                  "products.product_name   AS  product_name",
                  "products.image   AS  image",
                  DB::raw("concat('$hostUrl',products.image)   AS  image_url")
                   )
                 ->join ( 'unit as unit' ,'products.unit_id', '=', 'unit.id'  )
                 ->join ( 'category as category' ,'products.category_id', '=', 'category.id'  )
                 ->join ( 'status as status' ,'products.status_id', '=', 'status.id'  )
                 ->join ( 'feature as feature' ,'products.feature_id', '=', 'feature.id'  )
                   ;

/***********This area refer to search and paginate  ****************/
/******************** Dont modify this code ************************/
if (count($request->input()) >=1) {
   foreach ($request->input() as $key=>$value) {
       if ($key != "_token" || $key !="page") {
           if (strpos($key, "key_") !== false) {
               $exp_key = explode("key_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                    $data=$data->where("products.$exp_key", "=", $value) ;
               }
           }
           if (strpos($key, "id_") !== false) {
               $exp_key = explode("id_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                if($exp_key == "from_date" || $exp_key == "to_date"){ 
                  if($exp_key =="from_date" ){ 
                    $exp_key = "created_at"; 
                    $value = $value." 00:00:00"; 
                    $data=$data->where("products.$exp_key", ">=", $value) ; 
                  }elseif($exp_key =="to_date"){ 
                    $exp_key = "created_at"; 
                    $value = $value." 23:59:59"; 
                    $data=$data->where("products.$exp_key", "<=", $value) ; 
                  } 
                }else{ 
                  $data=$data->where("products.$exp_key", "=", $value) ; 
                } 
 
               }
           }
       }
   }
}
 /********************************************************************/
 $data=$data->paginate(15);
        if (Auth::user()["tbl_users_type_id"] ==1) {
            $permissions = array(
                                 "insertNew"=>true,
                                 "viewPage"=>true,
                                 "delete"=>true,
                                 "update"=>true,
                                 );
           } else {     
            $permissions = array(
                                 "viewPage"=>  Permission::CheckPermission(1,"products"),
                                 "update"=>    Permission::CheckPermission(2,"products"),
                                 "insertNew"=> Permission::CheckPermission(3,"products"),
                                 "delete"=>    Permission::CheckPermission(4,"products"),
                                 );
   } 
       $array = array(
                     "records"=>$data,
                     "folderName"=>"products",
                     "table"=>"products",
                     "permissions"=>$permissions,
                     "lang"=>$lang,
                    );
    return view("adminDashboard.products.products" ,$array);
  }
  //  proccess 10000006
 function products_products_details(){
     return view("adminDashboard/products/ajax/products_products_details");
 }
function products_products_form_add(){
  //  proccess 10000005
       return view("adminDashboard/products/ajax/products_products_form_add");
  }
function products_products_form_add_save(Request $request){
  //  proccess 10000004
   $request->validate(products_products::rules());;
   $data=array(); 
   $data["unit_id"]= $request->input()["unit_id"] ; 
   $data["category_id"]= $request->input()["category_id"] ; 
   $data["price"]= $request->input()["price"] ; 
   $data["qty"]= $request->input()["qty"] ; 
   $data["status_id"]= $request->input()["status_id"] ; 
   $data["feature_id"]= $request->input()["feature_id"] ; 
   $data["desc"]= $request->input()["desc"] ; 
   $data["product_name"]= $request->input()["product_name"] ; 
if ($request->hasFile("image")) {
        $file = $request->file("image");
        $path  = $file->store("documents",["disk" => "uploads"]);
        $data["image"]= $path ; 
    }
$data["created_by"]=Auth::user()->id;
$insert = products_products::create($data);
if($insert){
  Session::flash("success_update",  __("public.flashMsg_SuccessInsert"));
     return response()->json(["response" => "inserted"]);
 }else{
   return response()->json(["response" => "error"]); 
 }
}
function products_products_form_update(){
  // proccess 10000001
    return view("adminDashboard/products/ajax/products_products_form_update");
}
function products_products_form_update_save(Request $request){
  // proccess 10000002
  $products_products = products_products::findOrFail($request->input()["id"]);
  //$request->validate(products_products::rules());;
  $data = array();
  $data["unit_id"]= $request->input()["unit_id"] ; 
  $data["category_id"]= $request->input()["category_id"] ; 
  $data["price"]= $request->input()["price"] ; 
  $data["qty"]= $request->input()["qty"] ; 
  $data["status_id"]= $request->input()["status_id"] ; 
  $data["feature_id"]= $request->input()["feature_id"] ; 
  $data["desc"]= $request->input()["desc"] ; 
  $data["product_name"]= $request->input()["product_name"] ; 
 if ($request->hasFile("image")) {
       // remove old photo from Storage
        Storage::disk("uploads")->delete($products_products->image);
        $file = $request->file("image");
        $path  = $file->store("documents",["disk" => "uploads"]);
        $data["image"]= $path ; 
                } 
  $data["updated_by"]=Auth::user()["id"];
  $data["updated_at"]=date("Y-m-d H:i:s" );
   $updated = products_products::where("id","=",$request->input()["id"])->update($data);
  if($updated){ 
     Session::flash("success_update",  __("public.flashMsg_SuccessUpdate"));
     return response()->json(array("response"=>"updated"));
   }else{
    return response()->json(array("response"=>"error")); 
   }
}
         
         
         
 /****************End Table (products) Functionality******************/
         
         
         
  
  
 }
