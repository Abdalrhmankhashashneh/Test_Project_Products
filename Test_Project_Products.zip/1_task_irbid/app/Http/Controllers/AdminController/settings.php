<?php 
namespace App\Http\Controllers\AdminController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\SystemController\Delete;
use App\Http\Controllers\SystemController\Permission;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use App\Models\Admin\settings_category;
use App\Models\Admin\settings_unit;
use App\Models\Admin\settings_status;
use App\Models\Admin\settings_feature;
use App\Http\Controllers\AdminController\UserAuthController;
class settings extends Controller
{
 /*  
  This controller has been generated Automatically by generatesystems.com  
  */ 
/**************Start Table (category) Functionality **************/
function settings_category_delete_record(Request $request){
  //  proccess 10000008
 $id=$request->input("id");
 $table=$request->input("table");
 $id_name = $table . "_id";
 if(Delete::checkRow($id_name,$id)){
 return response()->json(array("response"=>"not_allow"));
 }else{
    if(DB::table($table)->where("id", $id)->delete()){                    
      return response()->json(array("response"=>"deleted"));                
  } 
   return response()->json(array("response"=>"error")); 
  }
}
function settings_category(Request $request)
  {
  //  proccess 10000007
  $lang =app()->getLocale();   
  $host = request()->getHttpHost();   
  $hostUrl = "https://".$host."/uploads/documents/";  
  $data = settings_category::select(    
                  "category.id   AS  id",
                  "category.category_en   AS  category_en",
                  "category.category_ar   AS  category_ar"
                   )
                   ;

/***********This area refer to search and paginate  ****************/
/******************** Dont modify this code ************************/
if (count($request->input()) >=1) {
   foreach ($request->input() as $key=>$value) {
       if ($key != "_token" || $key !="page") {
           if (strpos($key, "key_") !== false) {
               $exp_key = explode("key_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                    $data=$data->where("category.$exp_key", "=", $value) ;
               }
           }
           if (strpos($key, "id_") !== false) {
               $exp_key = explode("id_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                if($exp_key == "from_date" || $exp_key == "to_date"){ 
                  if($exp_key =="from_date" ){ 
                    $exp_key = "created_at"; 
                    $value = $value." 00:00:00"; 
                    $data=$data->where("category.$exp_key", ">=", $value) ; 
                  }elseif($exp_key =="to_date"){ 
                    $exp_key = "created_at"; 
                    $value = $value." 23:59:59"; 
                    $data=$data->where("category.$exp_key", "<=", $value) ; 
                  } 
                }else{ 
                  $data=$data->where("category.$exp_key", "=", $value) ; 
                } 
 
               }
           }
       }
   }
}
 /********************************************************************/
 $data=$data->paginate(15);
        if (Auth::user()["tbl_users_type_id"] ==1) {
            $permissions = array(
                                 "insertNew"=>true,
                                 "viewPage"=>true,
                                 "delete"=>true,
                                 "update"=>true,
                                 );
           } else {     
            $permissions = array(
                                 "viewPage"=>  Permission::CheckPermission(1,"category"),
                                 "update"=>    Permission::CheckPermission(2,"category"),
                                 "insertNew"=> Permission::CheckPermission(3,"category"),
                                 "delete"=>    Permission::CheckPermission(4,"category"),
                                 );
   } 
       $array = array(
                     "records"=>$data,
                     "folderName"=>"settings",
                     "table"=>"category",
                     "permissions"=>$permissions,
                     "lang"=>$lang,
                    );
    return view("adminDashboard.settings.category" ,$array);
  }
function settings_category_form_add(){
  //  proccess 10000005
       return view("adminDashboard/settings/ajax/settings_category_form_add");
  }
function settings_category_form_add_save(Request $request){
  //  proccess 10000004
   $request->validate(settings_category::rules());;
   $data=array(); 
   $data["category_en"]=  $request->input()["category_en"] ; 
   $data["category_ar"]=  $request->input()["category_ar"] ; 
$data["created_by"]=Auth::user()->id;
$insert = settings_category::create($data);
if($insert){
  Session::flash("success_update",  __("public.flashMsg_SuccessInsert"));
     return response()->json(["response" => "inserted"]);
 }else{
   return response()->json(["response" => "error"]); 
 }
}
function settings_category_form_update(){
  // proccess 10000001
    return view("adminDashboard/settings/ajax/settings_category_form_update");
}
function settings_category_form_update_save(Request $request){
  // proccess 10000002
  $settings_category = settings_category::findOrFail($request->input()["id"]);
  //$request->validate(settings_category::rules());;
  $data = array();
  $data["category_en"]= $request->input()["category_en"] ; 
  $data["category_ar"]= $request->input()["category_ar"] ; 
  $data["updated_by"]=Auth::user()["id"];
  $data["updated_at"]=date("Y-m-d H:i:s" );
   $updated = settings_category::where("id","=",$request->input()["id"])->update($data);
  if($updated){ 
     Session::flash("success_update",  __("public.flashMsg_SuccessUpdate"));
     return response()->json(array("response"=>"updated"));
   }else{
    return response()->json(array("response"=>"error")); 
   }
}
         
         
         
 /****************End Table (category) Functionality******************/
         
         
         
/**************Start Table (unit) Functionality **************/
function settings_unit_delete_record(Request $request){
  //  proccess 10000008
 $id=$request->input("id");
 $table=$request->input("table");
 $id_name = $table . "_id";
 if(Delete::checkRow($id_name,$id)){
 return response()->json(array("response"=>"not_allow"));
 }else{
    if(DB::table($table)->where("id", $id)->delete()){                    
      return response()->json(array("response"=>"deleted"));                
  } 
   return response()->json(array("response"=>"error")); 
  }
}
function settings_unit(Request $request)
  {
  //  proccess 10000007
  $lang =app()->getLocale();   
  $host = request()->getHttpHost();   
  $hostUrl = "https://".$host."/uploads/documents/";  
  $data = settings_unit::select(    
                  "unit.id   AS  id",
                  "unit.unit_en   AS  unit_en",
                  "unit.unit_ar   AS  unit_ar"
                   )
                   ;

/***********This area refer to search and paginate  ****************/
/******************** Dont modify this code ************************/
if (count($request->input()) >=1) {
   foreach ($request->input() as $key=>$value) {
       if ($key != "_token" || $key !="page") {
           if (strpos($key, "key_") !== false) {
               $exp_key = explode("key_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                    $data=$data->where("unit.$exp_key", "=", $value) ;
               }
           }
           if (strpos($key, "id_") !== false) {
               $exp_key = explode("id_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                if($exp_key == "from_date" || $exp_key == "to_date"){ 
                  if($exp_key =="from_date" ){ 
                    $exp_key = "created_at"; 
                    $value = $value." 00:00:00"; 
                    $data=$data->where("unit.$exp_key", ">=", $value) ; 
                  }elseif($exp_key =="to_date"){ 
                    $exp_key = "created_at"; 
                    $value = $value." 23:59:59"; 
                    $data=$data->where("unit.$exp_key", "<=", $value) ; 
                  } 
                }else{ 
                  $data=$data->where("unit.$exp_key", "=", $value) ; 
                } 
 
               }
           }
       }
   }
}
 /********************************************************************/
 $data=$data->paginate(15);
        if (Auth::user()["tbl_users_type_id"] ==1) {
            $permissions = array(
                                 "insertNew"=>true,
                                 "viewPage"=>true,
                                 "delete"=>true,
                                 "update"=>true,
                                 );
           } else {     
            $permissions = array(
                                 "viewPage"=>  Permission::CheckPermission(1,"unit"),
                                 "update"=>    Permission::CheckPermission(2,"unit"),
                                 "insertNew"=> Permission::CheckPermission(3,"unit"),
                                 "delete"=>    Permission::CheckPermission(4,"unit"),
                                 );
   } 
       $array = array(
                     "records"=>$data,
                     "folderName"=>"settings",
                     "table"=>"unit",
                     "permissions"=>$permissions,
                     "lang"=>$lang,
                    );
    return view("adminDashboard.settings.unit" ,$array);
  }
function settings_unit_form_add(){
  //  proccess 10000005
       return view("adminDashboard/settings/ajax/settings_unit_form_add");
  }
function settings_unit_form_add_save(Request $request){
  //  proccess 10000004
   $request->validate(settings_unit::rules());;
   $data=array(); 
   $data["unit_en"]=  $request->input()["unit_en"] ; 
   $data["unit_ar"]=  $request->input()["unit_ar"] ; 
$data["created_by"]=Auth::user()->id;
$insert = settings_unit::create($data);
if($insert){
  Session::flash("success_update",  __("public.flashMsg_SuccessInsert"));
     return response()->json(["response" => "inserted"]);
 }else{
   return response()->json(["response" => "error"]); 
 }
}
function settings_unit_form_update(){
  // proccess 10000001
    return view("adminDashboard/settings/ajax/settings_unit_form_update");
}
function settings_unit_form_update_save(Request $request){
  // proccess 10000002
  $settings_unit = settings_unit::findOrFail($request->input()["id"]);
  //$request->validate(settings_unit::rules());;
  $data = array();
  $data["unit_en"]= $request->input()["unit_en"] ; 
  $data["unit_ar"]= $request->input()["unit_ar"] ; 
  $data["updated_by"]=Auth::user()["id"];
  $data["updated_at"]=date("Y-m-d H:i:s" );
   $updated = settings_unit::where("id","=",$request->input()["id"])->update($data);
  if($updated){ 
     Session::flash("success_update",  __("public.flashMsg_SuccessUpdate"));
     return response()->json(array("response"=>"updated"));
   }else{
    return response()->json(array("response"=>"error")); 
   }
}
         
         
         
 /****************End Table (unit) Functionality******************/
         
         
         
/**************Start Table (status) Functionality **************/
function settings_status_delete_record(Request $request){
  //  proccess 10000008
 $id=$request->input("id");
 $table=$request->input("table");
 $id_name = $table . "_id";
 if(Delete::checkRow($id_name,$id)){
 return response()->json(array("response"=>"not_allow"));
 }else{
    if(DB::table($table)->where("id", $id)->delete()){                    
      return response()->json(array("response"=>"deleted"));                
  } 
   return response()->json(array("response"=>"error")); 
  }
}
function settings_status(Request $request)
  {
  //  proccess 10000007
  $lang =app()->getLocale();   
  $host = request()->getHttpHost();   
  $hostUrl = "https://".$host."/uploads/documents/";  
  $data = settings_status::select(    
                  "status.id   AS  id",
                  "status.status_en   AS  status_en",
                  "status.status_ar   AS  status_ar"
                   )
                   ;

/***********This area refer to search and paginate  ****************/
/******************** Dont modify this code ************************/
if (count($request->input()) >=1) {
   foreach ($request->input() as $key=>$value) {
       if ($key != "_token" || $key !="page") {
           if (strpos($key, "key_") !== false) {
               $exp_key = explode("key_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                    $data=$data->where("status.$exp_key", "=", $value) ;
               }
           }
           if (strpos($key, "id_") !== false) {
               $exp_key = explode("id_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                if($exp_key == "from_date" || $exp_key == "to_date"){ 
                  if($exp_key =="from_date" ){ 
                    $exp_key = "created_at"; 
                    $value = $value." 00:00:00"; 
                    $data=$data->where("status.$exp_key", ">=", $value) ; 
                  }elseif($exp_key =="to_date"){ 
                    $exp_key = "created_at"; 
                    $value = $value." 23:59:59"; 
                    $data=$data->where("status.$exp_key", "<=", $value) ; 
                  } 
                }else{ 
                  $data=$data->where("status.$exp_key", "=", $value) ; 
                } 
 
               }
           }
       }
   }
}
 /********************************************************************/
 $data=$data->paginate(15);
        if (Auth::user()["tbl_users_type_id"] ==1) {
            $permissions = array(
                                 "insertNew"=>true,
                                 "viewPage"=>true,
                                 "delete"=>true,
                                 "update"=>true,
                                 );
           } else {     
            $permissions = array(
                                 "viewPage"=>  Permission::CheckPermission(1,"status"),
                                 "update"=>    Permission::CheckPermission(2,"status"),
                                 "insertNew"=> Permission::CheckPermission(3,"status"),
                                 "delete"=>    Permission::CheckPermission(4,"status"),
                                 );
   } 
       $array = array(
                     "records"=>$data,
                     "folderName"=>"settings",
                     "table"=>"status",
                     "permissions"=>$permissions,
                     "lang"=>$lang,
                    );
    return view("adminDashboard.settings.status" ,$array);
  }
function settings_status_form_add(){
  //  proccess 10000005
       return view("adminDashboard/settings/ajax/settings_status_form_add");
  }
function settings_status_form_add_save(Request $request){
  //  proccess 10000004
   $request->validate(settings_status::rules());;
   $data=array(); 
   $data["status_en"]=  $request->input()["status_en"] ; 
   $data["status_ar"]=  $request->input()["status_ar"] ; 
$data["created_by"]=Auth::user()->id;
$insert = settings_status::create($data);
if($insert){
  Session::flash("success_update",  __("public.flashMsg_SuccessInsert"));
     return response()->json(["response" => "inserted"]);
 }else{
   return response()->json(["response" => "error"]); 
 }
}
function settings_status_form_update(){
  // proccess 10000001
    return view("adminDashboard/settings/ajax/settings_status_form_update");
}
function settings_status_form_update_save(Request $request){
  // proccess 10000002
  $settings_status = settings_status::findOrFail($request->input()["id"]);
  //$request->validate(settings_status::rules());;
  $data = array();
  $data["status_en"]= $request->input()["status_en"] ; 
  $data["status_ar"]= $request->input()["status_ar"] ; 
  $data["updated_by"]=Auth::user()["id"];
  $data["updated_at"]=date("Y-m-d H:i:s" );
   $updated = settings_status::where("id","=",$request->input()["id"])->update($data);
  if($updated){ 
     Session::flash("success_update",  __("public.flashMsg_SuccessUpdate"));
     return response()->json(array("response"=>"updated"));
   }else{
    return response()->json(array("response"=>"error")); 
   }
}
         
         
         
 /****************End Table (status) Functionality******************/
         
         
         
/**************Start Table (feature) Functionality **************/
function settings_feature_delete_record(Request $request){
  //  proccess 10000008
 $id=$request->input("id");
 $table=$request->input("table");
 $id_name = $table . "_id";
 if(Delete::checkRow($id_name,$id)){
 return response()->json(array("response"=>"not_allow"));
 }else{
    if(DB::table($table)->where("id", $id)->delete()){                    
      return response()->json(array("response"=>"deleted"));                
  } 
   return response()->json(array("response"=>"error")); 
  }
}
function settings_feature(Request $request)
  {
  //  proccess 10000007
  $lang =app()->getLocale();   
  $host = request()->getHttpHost();   
  $hostUrl = "https://".$host."/uploads/documents/";  
  $data = settings_feature::select(    
                  "feature.id   AS  id",
                  "feature.feature_en   AS  feature_en",
                  "feature.feature_ar   AS  feature_ar"
                   )
                   ;

/***********This area refer to search and paginate  ****************/
/******************** Dont modify this code ************************/
if (count($request->input()) >=1) {
   foreach ($request->input() as $key=>$value) {
       if ($key != "_token" || $key !="page") {
           if (strpos($key, "key_") !== false) {
               $exp_key = explode("key_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                    $data=$data->where("feature.$exp_key", "=", $value) ;
               }
           }
           if (strpos($key, "id_") !== false) {
               $exp_key = explode("id_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                if($exp_key == "from_date" || $exp_key == "to_date"){ 
                  if($exp_key =="from_date" ){ 
                    $exp_key = "created_at"; 
                    $value = $value." 00:00:00"; 
                    $data=$data->where("feature.$exp_key", ">=", $value) ; 
                  }elseif($exp_key =="to_date"){ 
                    $exp_key = "created_at"; 
                    $value = $value." 23:59:59"; 
                    $data=$data->where("feature.$exp_key", "<=", $value) ; 
                  } 
                }else{ 
                  $data=$data->where("feature.$exp_key", "=", $value) ; 
                } 
 
               }
           }
       }
   }
}
 /********************************************************************/
 $data=$data->paginate(15);
        if (Auth::user()["tbl_users_type_id"] ==1) {
            $permissions = array(
                                 "insertNew"=>true,
                                 "viewPage"=>true,
                                 "delete"=>true,
                                 "update"=>true,
                                 );
           } else {     
            $permissions = array(
                                 "viewPage"=>  Permission::CheckPermission(1,"feature"),
                                 "update"=>    Permission::CheckPermission(2,"feature"),
                                 "insertNew"=> Permission::CheckPermission(3,"feature"),
                                 "delete"=>    Permission::CheckPermission(4,"feature"),
                                 );
   } 
       $array = array(
                     "records"=>$data,
                     "folderName"=>"settings",
                     "table"=>"feature",
                     "permissions"=>$permissions,
                     "lang"=>$lang,
                    );
    return view("adminDashboard.settings.feature" ,$array);
  }
function settings_feature_form_add(){
  //  proccess 10000005
       return view("adminDashboard/settings/ajax/settings_feature_form_add");
  }
function settings_feature_form_add_save(Request $request){
  //  proccess 10000004
   $request->validate(settings_feature::rules());;
   $data=array(); 
   $data["feature_en"]=  $request->input()["feature_en"] ; 
   $data["feature_ar"]=  $request->input()["feature_ar"] ; 
$data["created_by"]=Auth::user()->id;
$insert = settings_feature::create($data);
if($insert){
  Session::flash("success_update",  __("public.flashMsg_SuccessInsert"));
     return response()->json(["response" => "inserted"]);
 }else{
   return response()->json(["response" => "error"]); 
 }
}
function settings_feature_form_update(){
  // proccess 10000001
    return view("adminDashboard/settings/ajax/settings_feature_form_update");
}
function settings_feature_form_update_save(Request $request){
  // proccess 10000002
  $settings_feature = settings_feature::findOrFail($request->input()["id"]);
  //$request->validate(settings_feature::rules());;
  $data = array();
  $data["feature_en"]= $request->input()["feature_en"] ; 
  $data["feature_ar"]= $request->input()["feature_ar"] ; 
  $data["updated_by"]=Auth::user()["id"];
  $data["updated_at"]=date("Y-m-d H:i:s" );
   $updated = settings_feature::where("id","=",$request->input()["id"])->update($data);
  if($updated){ 
     Session::flash("success_update",  __("public.flashMsg_SuccessUpdate"));
     return response()->json(array("response"=>"updated"));
   }else{
    return response()->json(array("response"=>"error")); 
   }
}
         
         
         
 /****************End Table (feature) Functionality******************/
         
         
         
  
  
 }
