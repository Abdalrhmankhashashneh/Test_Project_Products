<?php 
namespace App\Http\Controllers\AdminController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\SystemController\Delete;
use App\Http\Controllers\SystemController\Permission;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use App\Models\Admin\administrator_users;
use App\Models\Admin\administrator_tbl_users_type;
use App\Http\Controllers\AdminController\UserAuthController;
class administrator extends Controller
{
 /*  
  This controller has been generated Automatically by generatesystems.com  
  */ 
/**************Start Table (users) Functionality **************/
/************* View Permission ***************/
 
    public function permission_form_roles(Request $request) 
    { 
  //  proccess 100000011
       return view("adminDashboard/administrator/ajax/permission_form_roles", ["tbl_users_type_id"=>$request->tbl_users_type_id]);
    }
 
/************* Set Permission ***************/
    public function insertPermissions(Request $request)
    {
  //  proccess 100000010
        $data=array(
          "tbl_users_type_id"=>$request->input("tbl_users_type_id"),
          "tbl_adv_menu_id"=>$request->input("tbl_adv_menu_id"),
          "tbl_adv_menu_sub_id"=>$request->input("tbl_adv_menu_sub_id"),
          "tbl_actions_id"=>$request->input("tbl_action_id") );
        if (DB::table("tbl_permissions")->insert($data)) {
            return response([
                "message"=>"inserted",
                ]);
        } else {
            return response([
                "message"=>"error"
                ]);
        }
    }

/************* Remove Permission ***************/
    public function removePermissions(Request $request)
    {
  //  proccess 10000009
       $data =  DB::table("tbl_permissions")->where([
          ["tbl_users_type_id", "=", $request->input("tbl_users_type_id")],
          ["tbl_adv_menu_id", "=", $request->input("tbl_adv_menu_id")],
          ["tbl_adv_menu_sub_id", "=",$request->input("tbl_adv_menu_sub_id")],
          ["tbl_actions_id", "=", $request->input("tbl_action_id")]
      ])->delete();
        if ($data) {
            return response([
                "message"=>"removed",
                ]);
        } else {
            return response([
                "message"=>"error"
                ]);
        }
    }
function administrator_users_delete_record(Request $request){
  //  proccess 10000008
 $id=$request->input("id");
 $table=$request->input("table");
 $id_name = $table . "_id";
 if(Delete::checkRow($id_name,$id)){
 return response()->json(array("response"=>"not_allow"));
 }else{
    if(DB::table($table)->where("id", $id)->delete()){                    
      return response()->json(array("response"=>"deleted"));                
  } 
   return response()->json(array("response"=>"error")); 
  }
}
function administrator_users(Request $request)
  {
  //  proccess 10000007
  $lang =app()->getLocale();   
  $host = request()->getHttpHost();   
  $hostUrl = "https://".$host."/uploads/documents/";  
  $data = administrator_users::select(    
"users.active_status_id AS active_status_id",
"users.tbl_users_type_id AS tbl_users_type_id",
                  "users.id   AS  id",
                  "users.name   AS  name",
                  "users.email   AS  email",
                  "users.profile_photo_path   AS  profile_photo_path",
                  DB::raw("concat('$hostUrl',users.profile_photo_path)   AS  profile_photo_path_url"),
                  "tbl_users_type.name    AS  tbl_users_type_id_name",
                  "users.tbl_users_type_id   AS  tbl_users_type_id"
                   )
                 ->join ( 'tbl_users_type as tbl_users_type' ,'users.tbl_users_type_id', '=', 'tbl_users_type.id'  )
                   ;

/***********This area refer to search and paginate  ****************/
/******************** Dont modify this code ************************/
if (count($request->input()) >=1) {
   foreach ($request->input() as $key=>$value) {
       if ($key != "_token" || $key !="page") {
           if (strpos($key, "key_") !== false) {
               $exp_key = explode("key_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                    $data=$data->where("users.$exp_key", "=", $value) ;
               }
           }
           if (strpos($key, "id_") !== false) {
               $exp_key = explode("id_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                if($exp_key == "from_date" || $exp_key == "to_date"){ 
                  if($exp_key =="from_date" ){ 
                    $exp_key = "created_at"; 
                    $value = $value." 00:00:00"; 
                    $data=$data->where("users.$exp_key", ">=", $value) ; 
                  }elseif($exp_key =="to_date"){ 
                    $exp_key = "created_at"; 
                    $value = $value." 23:59:59"; 
                    $data=$data->where("users.$exp_key", "<=", $value) ; 
                  } 
                }else{ 
                  $data=$data->where("users.$exp_key", "=", $value) ; 
                } 
 
               }
           }
       }
   }
}
 /********************************************************************/
 $data=$data->paginate(15);
        if (Auth::user()["tbl_users_type_id"] ==1) {
            $permissions = array(
                                 "insertNew"=>true,
                                 "viewPage"=>true,
                                 "delete"=>true,
                                 "update"=>true,
                                 );
           } else {     
            $permissions = array(
                                 "viewPage"=>  Permission::CheckPermission(1,"users"),
                                 "update"=>    Permission::CheckPermission(2,"users"),
                                 "insertNew"=> Permission::CheckPermission(3,"users"),
                                 "delete"=>    Permission::CheckPermission(4,"users"),
                                 );
   } 
       $array = array(
                     "records"=>$data,
                     "folderName"=>"administrator",
                     "table"=>"users",
                     "permissions"=>$permissions,
                     "lang"=>$lang,
                    );
    return view("adminDashboard.administrator.users" ,$array);
  }
function administrator_users_form_add(){
  //  proccess 10000005
       return view("adminDashboard/administrator/ajax/administrator_users_form_add");
  }
function administrator_users_form_add_save(Request $request){
  //  proccess 10000004
   $request->validate(administrator_users::rules());;
   $data=array(); 
   $data["name"]= $request->input()["name"] ; 
   $data["email"]= $request->input()["email"] ; 
   $data["tbl_users_type_id"]= $request->input()["tbl_users_type_id"] ; 
if ($request->hasFile("profile_photo_path")) {
        $file = $request->file("profile_photo_path");
        $path  = $file->store("documents",["disk" => "uploads"]);
        $data["profile_photo_path"]= $path ; 
    }
  $data["active_status_id"]= 1; 
  $data["password"]=  Hash::make(123456)  ; 
$data["created_by"]=Auth::user()->id;
$insert = administrator_users::create($data);
if($insert){
  Session::flash("success_update",  __("public.flashMsg_SuccessInsert"));
     return response()->json(["response" => "inserted"]);
 }else{
   return response()->json(["response" => "error"]); 
 }
}
function administrator_users_form_update(){
  // proccess 10000001
    return view("adminDashboard/administrator/ajax/administrator_users_form_update");
}
function administrator_users_form_update_save(Request $request){
  // proccess 10000002
  $administrator_users = administrator_users::findOrFail($request->input()["id"]);
  //$request->validate(administrator_users::rules());;
  $data = array();
  $data["name"]= $request->input()["name"] ; 
  $data["email"]= $request->input()["email"] ; 
  $data["tbl_users_type_id"]= $request->input()["tbl_users_type_id"] ; 
 if ($request->hasFile("profile_photo_path")) {
       // remove old photo from Storage
        Storage::disk("uploads")->delete($administrator_users->profile_photo_path);
        $file = $request->file("profile_photo_path");
        $path  = $file->store("documents",["disk" => "uploads"]);
        $data["profile_photo_path"]= $path ; 
                } 
  $data["updated_by"]=Auth::user()["id"];
  $data["updated_at"]=date("Y-m-d H:i:s" );
   $updated = administrator_users::where("id","=",$request->input()["id"])->update($data);
  if($updated){ 
     Session::flash("success_update",  __("public.flashMsg_SuccessUpdate"));
     return response()->json(array("response"=>"updated"));
   }else{
    return response()->json(array("response"=>"error")); 
   }
}
         
         
         
 /****************End Table (users) Functionality******************/
         
         
         
/**************Start Table (tbl_users_type) Functionality **************/
function administrator_tbl_users_type_delete_record(Request $request){
  //  proccess 10000008
 $id=$request->input("id");
 $table=$request->input("table");
 $id_name = $table . "_id";
 if(Delete::checkRow($id_name,$id)){
 return response()->json(array("response"=>"not_allow"));
 }else{
    if(DB::table($table)->where("id", $id)->delete()){                    
      return response()->json(array("response"=>"deleted"));                
  } 
   return response()->json(array("response"=>"error")); 
  }
}
function administrator_tbl_users_type(Request $request)
  {
  //  proccess 10000007
  $lang =app()->getLocale();   
  $host = request()->getHttpHost();   
  $hostUrl = "https://".$host."/uploads/documents/";  
  $data = administrator_tbl_users_type::select(    
                  "tbl_users_type.id   AS  id",
                  "tbl_users_type.name   AS  name"
                   )
                   ;

/***********This area refer to search and paginate  ****************/
/******************** Dont modify this code ************************/
if (count($request->input()) >=1) {
   foreach ($request->input() as $key=>$value) {
       if ($key != "_token" || $key !="page") {
           if (strpos($key, "key_") !== false) {
               $exp_key = explode("key_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                    $data=$data->where("tbl_users_type.$exp_key", "=", $value) ;
               }
           }
           if (strpos($key, "id_") !== false) {
               $exp_key = explode("id_", $key);
               $exp_key = $exp_key[1];
               if ($value != null && $value != ""  && $value > 0) {
                if($exp_key == "from_date" || $exp_key == "to_date"){ 
                  if($exp_key =="from_date" ){ 
                    $exp_key = "created_at"; 
                    $value = $value." 00:00:00"; 
                    $data=$data->where("tbl_users_type.$exp_key", ">=", $value) ; 
                  }elseif($exp_key =="to_date"){ 
                    $exp_key = "created_at"; 
                    $value = $value." 23:59:59"; 
                    $data=$data->where("tbl_users_type.$exp_key", "<=", $value) ; 
                  } 
                }else{ 
                  $data=$data->where("tbl_users_type.$exp_key", "=", $value) ; 
                } 
 
               }
           }
       }
   }
}
 /********************************************************************/
 $data=$data->paginate(15);
        if (Auth::user()["tbl_users_type_id"] ==1) {
            $permissions = array(
                                 "insertNew"=>true,
                                 "viewPage"=>true,
                                 "delete"=>true,
                                 "update"=>true,
                                 );
           } else {     
            $permissions = array(
                                 "viewPage"=>  Permission::CheckPermission(1,"tbl_users_type"),
                                 "update"=>    Permission::CheckPermission(2,"tbl_users_type"),
                                 "insertNew"=> Permission::CheckPermission(3,"tbl_users_type"),
                                 "delete"=>    Permission::CheckPermission(4,"tbl_users_type"),
                                 );
   } 
       $array = array(
                     "records"=>$data,
                     "folderName"=>"administrator",
                     "table"=>"tbl_users_type",
                     "permissions"=>$permissions,
                     "lang"=>$lang,
                    );
    return view("adminDashboard.administrator.tbl_users_type" ,$array);
  }
function administrator_tbl_users_type_form_add(){
  //  proccess 10000005
       return view("adminDashboard/administrator/ajax/administrator_tbl_users_type_form_add");
  }
function administrator_tbl_users_type_form_add_save(Request $request){
  //  proccess 10000004
   $request->validate(administrator_tbl_users_type::rules());;
   $data=array(); 
   $data["name"]=  $request->input()["name"] ; 
$data["created_by"]=Auth::user()->id;
$insert = administrator_tbl_users_type::create($data);
if($insert){
  Session::flash("success_update",  __("public.flashMsg_SuccessInsert"));
     return response()->json(["response" => "inserted"]);
 }else{
   return response()->json(["response" => "error"]); 
 }
}
function administrator_tbl_users_type_form_update(){
  // proccess 10000001
    return view("adminDashboard/administrator/ajax/administrator_tbl_users_type_form_update");
}
function administrator_tbl_users_type_form_update_save(Request $request){
  // proccess 10000002
  $administrator_tbl_users_type = administrator_tbl_users_type::findOrFail($request->input()["id"]);
  //$request->validate(administrator_tbl_users_type::rules());;
  $data = array();
  $data["name"]= $request->input()["name"] ; 
  $data["updated_by"]=Auth::user()["id"];
  $data["updated_at"]=date("Y-m-d H:i:s" );
   $updated = administrator_tbl_users_type::where("id","=",$request->input()["id"])->update($data);
  if($updated){ 
     Session::flash("success_update",  __("public.flashMsg_SuccessUpdate"));
     return response()->json(array("response"=>"updated"));
   }else{
    return response()->json(array("response"=>"error")); 
   }
}
         
         
         
 /****************End Table (tbl_users_type) Functionality******************/
         
         
         
  
  
 }
