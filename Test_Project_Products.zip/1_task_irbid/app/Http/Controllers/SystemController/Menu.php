<?php

namespace App\Http\Controllers\SystemController;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

function print_object($records)
{
    echo "<pre>";
    print_r($records);
    echo "</pre>";
}
class Menu extends Controller
{
    public static function getMenu($theme)
    {
        if (Auth::user()->tbl_users_type_id==1) {
            if ($theme == 'adminlte') {
                self::getAdmin_AdminLteTheme();
            } elseif ($theme == 'Fit') {
                self::getAdmin_FitoTheme();
            } else {
                self::getAdmin_AdminLteTheme();
            }
        } else {
            if ($theme == 'adminlte') {
                self::getUser_AdminLteTheme();
            } elseif ($theme == 'Fit') {
                self::getUser_FitoTheme();
            } else {
                self::getUser_AdminLteTheme();
            }
        }
    }


    public static function getAdmin_FitoTheme()
    {
        $moduleName = Route::getFacadeRoot()->current()->uri();
        $moduleName = strtolower($moduleName);
        $newName = explode('adminpanel/', $moduleName);
        $moduleName_new = $newName[1] ;
        $output ='<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">';
        $output .='<i class="flaticon-381-networking"></i>';
        $output .=' <span class="nav-text">'.__("public.dashboardMenu").'</span>';
        $output .='  </a>';
        $output .="<ul>";
        $output .='<li><a href="dashboard">Dashboard</a></li>';
        $output .="</ul>";
        $output .="</li>";

        $menuLink = self::getMainMenuAdminLte();

        if ($menuLink !== false) {
            $output ='<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">';
            $output .='<i class="flaticon-381-networking"></i>';
            $output .=' <span class="nav-text">'.__("public.dashboardMenu").'</span>';
            $output .='  </a>';



            $output .="<ul>";
            $output .='<li><a href="dashboard">Dashboard</a></li>';
            $output .="</ul>";
            $output .="</li>";



            $FoucMainMenu ='';
            $activeMainMenu ='';
            foreach ($menuLink  as $record) {
                $key = $record->id;
                $val = strtolower($record->moduleName);
                $icon = ($record->icon != null ) ? $record->icon : 'fa-chart-pie' ;

              
                $mainVal =$val ;
                if ($moduleNameClean = self::checkString($moduleName, $mainVal)) {
                    $FoucMainMenu ='active';
                    $activeMainMenu ='menu-open';
                } else {
                    $FoucMainMenu ='';
                    $activeMainMenu ='';
                }

                $output .='<li><a class="has-arrow  " href="javascript:void()" aria-expanded="false">';
                $output .='<i class="'.$icon.'"></i>';
                $output .=' <span class="nav-text">'. __("menu.mainmenu_$val").'</span>';
                $output .='  </a>';



                $subMenus = self::getSubmenusAdminLte($key);


                if ($subMenus !== false) {
                    $output .='<ul>';

                    $activeMenu = '';
                    foreach ($subMenus as $subKey=>$subVal) {
                        $linkPage =  $val.'_'.$subVal;
                        $linkPage = strtolower($linkPage);

                        if ($linkPage == $moduleName_new) {
                            $activeMenu = 'active';
                        } else {
                            $activeMenu = '';
                        }
                        $output .='<li><a href="'.strtolower($linkPage).'">'.__("menu.submenu_$subVal").'</a></li>';
                    }

                    $output .='</ul>';
                }




                $output .='</li>';
            }
        }




        echo $output;
    }
    public static function getUser_FitoTheme()
    {
        $moduleName = Route::getFacadeRoot()->current()->uri();
        $moduleName = strtolower($moduleName);
        $newName = explode('adminpanel/', $moduleName);
        $moduleName_new = $newName[1] ;
        $output ='<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">';
        $output .='<i class="flaticon-381-networking"></i>';
        $output .=' <span class="nav-text">'.__("public.dashboardMenu").'</span>';
        $output .='  </a>';
        $output .="<ul>";
        $output .='<li><a href="dashboard">Dashboard</a></li>';
        $output .="</ul>";
        $output .="</li>";


        $menuLink = self::getUserMainMenuAdminLte();
        if ($menuLink !== false) {
            $output ='<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">';
            $output .='<i class="flaticon-381-networking"></i>';
            $output .=' <span class="nav-text">'.__("public.dashboardMenu").'</span>';
            $output .='  </a>';



            $output .="<ul>";
            $output .='<li><a href="dashboard">Dashboard</a></li>';
            $output .="</ul>";
            $output .="</li>";



            $FoucMainMenu ='';
            $activeMainMenu ='';
            foreach ($menuLink  as $record) {
                $key = $record->id;
                $val = strtolower($record->moduleName);
                $icon = ($record->icon != null ) ? $record->icon : 'fa-chart-pie' ;

                // value = name
                $mainVal =$val ;
                if ($moduleNameClean = self::checkString($moduleName, $mainVal)) {
                    $FoucMainMenu ='active';
                    $activeMainMenu ='menu-open';
                } else {
                    $FoucMainMenu ='';
                    $activeMainMenu ='';
                }

                $output .='<li><a class="has-arrow  " href="javascript:void()" aria-expanded="false">';
                $output .='<i class="'.$icon.'"></i>';
                $output .=' <span class="nav-text">'. __("menu.mainmenu_$val").'</span>';
                $output .='  </a>';



                $subMenus = self::getUserSubmenusAdminLte($key);


                if ($subMenus !== false) {
                    $output .='<ul>';

                    $activeMenu = '';
                    foreach ($subMenus as $subKey=>$subVal) {
                        $linkPage =  $val.'_'.$subVal;
                        $linkPage = strtolower($linkPage);

                        if ($linkPage == $moduleName_new) {
                            $activeMenu = 'active';
                        } else {
                            $activeMenu = '';
                        }
                        $output .='<li><a href="'.strtolower($linkPage).'">'.__("menu.submenu_$subVal").'</a></li>';
                    }

                    $output .='</ul>';
                }




                $output .='</li>';
            }
        }




        echo $output;
    }
    public static function getUser_AdminLteTheme()
    {
        $moduleName = Route::getFacadeRoot()->current()->uri(); // adminPanel/tasks_no_action_task
        $moduleName = strtolower($moduleName);
        $newName = explode('adminpanel/', $moduleName);
        //  print_object($newName);
        $moduleName_new = $newName[1] ;
        $output ='<nav class="mt-2">';
        $output .='<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">';

        // start dashboard static page
        $output .='<li class="nav-item  ">';
        $output .='   <a href="#" class="nav-link  ">';
        $output .='     <i class="nav-icon fas fa-tachometer-alt"></i>';
        $output .='     <p>';
        $output .= __("public.dashboardMenu");
        ;
        $output .='       <i class="right fas fa-angle-left"></i>';
        $output .='     </p>';
        $output .='   </a>';
        $output .='   <ul class="nav nav-treeview">';
        $output .='     <li class="nav-item">';
        $output .='       <a href="mainPage" class="nav-link active">';
        $output .='         <i class="far fa-circle nav-icon"></i>';
        $output .='         <p>Dashboard  </p>';
        $output .='       </a>';
        $output .='     </li>';
        $output .='   </ul>';
        $output .=' </li>';
        // end dashboard static page

        $menuLink = self::getUserMainMenuAdminLte();
        if ($menuLink !== false) {
            //   print_object($menuLink);
            //   die();
            $FoucMainMenu ='';
            $activeMainMenu ='';
            foreach ($menuLink  as $record) {
                $key = $record->id;
                $val = strtolower($record->moduleName); // tasks
                $icon = ($record->icon != null) ? $record->icon : 'fa-chart-pie' ;
                // value = name
                $mainVal =$val ;
                if (self::checkStringNormalUser($moduleName, $mainVal)) {
                    $FoucMainMenu ='active';
                    $activeMainMenu ='menu-open';
                } else {
                    $FoucMainMenu ='';
                    $activeMainMenu ='';
                }
                $output .='<li class="nav-item '.strtolower($activeMainMenu).'">';

                $output .='<a href="#" class="nav-link '.$FoucMainMenu.' ">';
                $output .='<i class="nav-icon fas '.$icon.'"></i>';
                $output .='<p>';
                $output .= __("menu.mainmenu_$val");
                $output .='  <i class="right fas fa-angle-left"></i>';
                $output .='</p>';
                $output .='</a>';
                $output .='<ul class="nav nav-treeview">';
                $subMenus = self::getUserSubmenusAdminLte($key);
                //  print_object($subMenus);
             //

                if ($subMenus !== false) {
                    $activeMenu = '';
                    foreach ($subMenus as $subKey=>$subVal) {
                        $linkPage =  $val.'_'.$subVal;
                        if ($linkPage == $moduleName_new) {
                            $activeMenu = 'active';
                        } else {
                            $activeMenu = '';
                        }
                        $output .='<li class="nav-item ">';
                        $output .='<a href="'.strtolower($linkPage).'" class="nav-link '.$activeMenu.'">';
                        $output .='  <i class="far fa-circle nav-icon"></i>';
                        $output .='  <p>'.__("menu.submenu_$subVal").'</p>';
                        $output .=' </a>';
                        $output .=' </li>';
                    }
                }



                $output .='</ul>';
                $output .='</li>';
            }
        }
        $output .=' </ul>';
        $output .='</nav>';


        echo $output;
    }
    public static function getAdmin_AdminLteTheme()
    {
        $moduleName = Route::getFacadeRoot()->current()->uri();
        $moduleName = strtolower($moduleName);
        //$ex = explode('_', $moduleName);
        //$string = $ex[0];
        $newName = explode('adminpanel/', $moduleName);
        //  print_object($newName);
        $moduleName_new = $newName[1] ;
        $output ='<nav class="mt-2">';
        $output .='<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">';

        // start dashboard static page
        $output .='<li class="nav-item  ">';
        $output .='   <a href="#" class="nav-link  ">';
        $output .='     <i class="nav-icon fas fa-tachometer-alt"></i>';
        $output .='     <p>';
        $output .= __("public.dashboardMenu");
        ;
        $output .='       <i class="right fas fa-angle-left"></i>';
        $output .='     </p>';
        $output .='   </a>';
        $output .='   <ul class="nav nav-treeview">';
        $output .='     <li class="nav-item">';
        $output .='       <a href="mainPage" class="nav-link active">';
        $output .='         <i class="far fa-circle nav-icon"></i>';
        $output .='         <p>Dashboard  </p>';
        $output .='       </a>';
        $output .='     </li>';
        $output .='   </ul>';
        $output .=' </li>';
        // end dashboard static page


        $menuLink = self::getMainMenuAdminLte();

        if ($menuLink !== false) {
            //   print_object($menuLink);
            $FoucMainMenu ='';
            $activeMainMenu ='';
            foreach ($menuLink  as $record) {
                $key = $record->id;
                $val = strtolower($record->moduleName);
                $icon = ($record->icon != null) ? $record->icon : 'fa-chart-pie' ;
                // value = name
                $mainVal =$val ;
                if ($moduleNameClean = self::checkString($moduleName, $mainVal)) {
                    $FoucMainMenu ='active';
                    $activeMainMenu ='menu-open';
                } else {
                    $FoucMainMenu ='';
                    $activeMainMenu ='';
                }
                $output .='<li class="nav-item '.strtolower($activeMainMenu).'">';

                $output .='<a href="#" class="nav-link '.$FoucMainMenu.' ">';
                $output .='<i class="nav-icon fas '.$icon.'"></i>';
                $output .='<p>';
                $output .= __("menu.mainmenu_$val");
                $output .='  <i class="right fas fa-angle-left"></i>';
                $output .='</p>';
                $output .='</a>';
                $output .='<ul class="nav nav-treeview">';
                $subMenus = self::getSubmenusAdminLte($key);
                //  print_object($subMenus);
                 //

                if ($subMenus !== false) {
                    $activeMenu = '';
                    foreach ($subMenus as $subKey=>$subVal) {
                        $linkPage =  $val.'_'.$subVal;
                        $linkPage = strtolower($linkPage);

                        if ($linkPage == $moduleName_new) {
                            $activeMenu = 'active';
                        } else {
                            $activeMenu = '';
                        }
                        $output .='<li class="nav-item ">';
                        $output .='<a href="'.strtolower($linkPage).'" class="nav-link '.$activeMenu.'">';
                        $output .='  <i class="far fa-circle nav-icon"></i>';
                        $output .='  <p>'.__("menu.submenu_$subVal").'</p>';
                        $output .=' </a>';
                        $output .=' </li>';
                    }
                }



                $output .='</ul>';
                $output .='</li>';
            }
        }

        $output .=' </ul>';
        $output .='</nav>';

        echo $output;
    }

    public static function checkString($string, $word)
    {
        $ex = explode('_', $string);

        $string = $ex[0];
        $newName = explode('adminpanel/', $string);
        $string = $newName[1];
        if ($string == $word) {
            return true;
        }

        return false;
    }
    public static function checkStringNormalUser($string, $word)
    {
        $ex = explode('_', $string);

        $string = $ex[0];
        $newName = explode('adminpanel/', $string);
        $string = $newName[1];

        if ($string == $word) {
            return true;
        }

        return false;
    }
    public static function getMenuAlias($id)
    {
        $records = DB::select("select * from tbl_adv_menu where id='$id'");
        if (count($records) >= 1) {
            foreach ($records as $record) {
                return $record->menuAlias;
            }
        }
    }
    public static function getUserSubmenusAdminLte($tbl_adv_menu_id)
    {
        $tbl_users_type_id=Auth::user()->tbl_users_type_id;
        $sql = "SELECT
        tbl_adv_menu.moduleName,
        tbl_adv_menu_sub.page_name,
        tbl_adv_menu_sub.link
    FROM
        `tbl_permissions`
    JOIN tbl_adv_menu ON tbl_permissions.tbl_adv_menu_id = tbl_adv_menu.id
    JOIN tbl_adv_menu_sub ON tbl_permissions.tbl_adv_menu_sub_id = tbl_adv_menu_sub.id
    WHERE
         tbl_users_type_id = $tbl_users_type_id AND tbl_permissions.tbl_actions_id = 1 and tbl_permissions.tbl_adv_menu_id=$tbl_adv_menu_id ";
        $menus = array();
        $records =  DB::select(DB::raw($sql));
        ;
        if (count($records) >= 1) {
            foreach ($records as $record) {
                $menus[$record->page_name]=$record->link;
            }
            return $menus;
        }
        return false;
    }
    public static function getSubmenusAdminLte($tbl_adv_menu_id)
    {
        $records = DB::select("select * from tbl_adv_menu_sub where tbl_adv_menu_id='$tbl_adv_menu_id'  and hidden=0 order by sort asc");
        $menus = array();
        if (count($records) >= 1) {
            foreach ($records as $record) {
                $menus[$record->page_name]=$record->link;
            }
            return $menus;
        }
        return false;
    }
    public static function getMainMenuAdminLte()
    {
        $records = DB::select("select * from tbl_adv_menu  ORDER BY `tbl_adv_menu`.`sort` ASC");
        $menus = array();
        if (count($records) >= 1) {
            /* foreach ($records as $record) {
                 $menus[$record->id]=$record->moduleName;
             }*/
            return $records;
        }
        return false;
    }
    public static function getUserMainMenuAdminLte()
    {
        $tbl_users_type_id=Auth::user()->tbl_users_type_id;
        $sql = "SELECT 
        tbl_adv_menu.moduleName as moduleName,
        tbl_adv_menu.id as id,
        tbl_adv_menu.icon as icon 
        FROM `tbl_permissions` 
        join tbl_adv_menu on tbl_permissions.tbl_adv_menu_id = tbl_adv_menu.id
        join tbl_adv_menu_sub on tbl_adv_menu_sub.tbl_adv_menu_id=tbl_adv_menu.id
        where  tbl_users_type_id=$tbl_users_type_id AND tbl_permissions.tbl_actions_id = 1 
        group by tbl_permissions.tbl_adv_menu_id,tbl_adv_menu.moduleName,tbl_adv_menu.id,tbl_adv_menu.icon
        order by tbl_adv_menu_sub.sort asc
         ";
        $records =  DB::select(DB::raw($sql));
        ;
        $menus = array();
        if (count($records) >= 1) {
            /* foreach ($records as $record) {
                 $menus[$record->id]=$record->moduleName;
             }*/
            return $records;
        }
        return false;
    }

    public function users()
    {
        return view('adminstrator.users');
    }
}
