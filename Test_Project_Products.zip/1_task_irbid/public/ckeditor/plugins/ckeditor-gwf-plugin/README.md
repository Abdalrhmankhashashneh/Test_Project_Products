ckeditor-gwf-plugin
===================

Plugin for CKEditor to add GoogleWebFonts support.

To use this plugin:

1. copy ckeditor-gwf-plugin to ckeditor's plugin folder;
2. add 'ckeditor-gwf-plugin' to config.extraPlugins property;
3. add 'GoogleWebFonts;' to config.font_names property;
4. also you could override some plugins properties with config.gwfplugin;

For more details take a look in code.
